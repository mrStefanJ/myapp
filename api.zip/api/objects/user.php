<?php
class User{
 
    // database connection and table name
    private $conn;
    private $table_name = 'users';
 
    // object properties
    public $user_id;
    public $username;
    public $password;
    public $user_name;
 
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }

    // read users
    function read(){
    
        // select all query
        $query = "SELECT
                   u.user_id, u.user_name
                FROM
                    " . $this->table_name ." u";

        // prepare query statement
        $stmt = $this->conn->prepare($query);
        // execute query
        $stmt->execute();
    
        return $stmt;
    }

    // login user
    function login() {
    
        // select all query
        $query = "SELECT * FROM " . $this->table_name ." u
                WHERE u.username = ? AND u.password = ?";

        // prepare query statement
        $stmt = $this->conn->prepare($query);

        $this->user_name=htmlspecialchars(strip_tags($this->user_name));
        $this->user_id=htmlspecialchars(strip_tags($this->user_id));

        $stmt->bindParam(1, $this->username);
        $stmt->bindParam(2, $this->password);

        // execute query
        $stmt->execute();

        return $stmt;
    }
}