<?php
ini_set('display_errors', 'On');
error_reporting(E_ALL);
class Article{
 
    // database connection and table name
    private $conn;
    private $table_name = "articles";
 
    // object properties
    public $article_id;
    public $article_title;
    public $article_text;
    public $article_images;
    public $user_id;
    public $user_name;
    public $article_date_created;
 
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }

    // read articles
    function read(){
    
        // select all query
        $query = "SELECT
                    u.user_name as user_name, a.article_id, a.article_title, a.article_text, a.article_images, a.user_id
                FROM
                    " . $this->table_name . " a
                    LEFT JOIN
                        users u
                            ON a.user_id = u.user_id
                ORDER BY
                    a.article_date_created DESC";
    
        // prepare query statement
        $stmt = $this->conn->prepare($query);
    
        // execute query
        $stmt->execute();
    
        return $stmt;
    }

    // create article
    function create(){
    
        // query to insert record
        $query = "INSERT INTO
                    " . $this->table_name . "
                SET
                article_title = :article_title, 
                article_text = :article_text,
                article_images = :article_images,
                user_id = :user_id,
                article_date_created = :article_date_created";
    
        // prepare query
        $stmt = $this->conn->prepare($query);
    
        // sanitize
        $this->article_title=htmlspecialchars(strip_tags($this->article_title));
        $this->article_text=htmlspecialchars(strip_tags($this->article_text));
        $this->article_images=htmlspecialchars(strip_tags($this->article_images));
        $this->user_id=htmlspecialchars(strip_tags($this->user_id));
        $this->article_date_created=htmlspecialchars(strip_tags($this->article_date_created));
    
        // bind new values
        $stmt->bindParam(':article_title', $this->article_title);
        $stmt->bindParam(':article_text', $this->article_text);
        $stmt->bindParam(':article_images', $this->article_images);
        $stmt->bindParam(':user_id', $this->user_id);
        $stmt->bindParam(':article_date_created', $this->article_date_created);

        // execute query
        if($stmt->execute()){
            return true;
        }
    
        return false;
    }

    // used when filling up the update article form
    function filter(){
    
        // query to read single record
        $query = "SELECT
                    u.user_name as user_name, a.article_id, a.article_title, a.article_text, a.article_images, a.user_id
                FROM
                    " . $this->table_name . " a
                LEFT JOIN
                    users u
                        ON a.user_id = u.user_id
                WHERE
                    a.user_id = ?";
    
        // prepare query statement
        $stmt = $this->conn->prepare( $query );

        // bind id of article to be updated
        $stmt->bindParam(1, $this->user_id);

        // execute query
        $stmt->execute();

        return $stmt;
    }

    //retrieve only one article
    function readOne() {
        // query to read single record
        $query = "SELECT
        u.user_name as user_name, a.article_id, a.article_title, a.article_text, a.article_images, a.user_id
        FROM
        " . $this->table_name . " a
        LEFT JOIN
        users u
            ON a.user_id = u.user_id
        WHERE
        a.article_id = ?";

        // prepare query statement
        $stmt = $this->conn->prepare( $query );

        // bind id of article to be updated
        $stmt->bindParam(1, $this->article_id);

        // execute query
        $stmt->execute();

        return $stmt;
    }

    // update the article
    function update() {
    
        // update query
        $query = "UPDATE
                    " . $this->table_name . "
                SET
                article_title = :article_title,
                article_text = :article_text,
                article_images = :article_images,
                user_id = :user_id,
                article_date_created = :article_date_created
                WHERE
                    article_id = :article_id";
    
        // prepare query statement
        $stmt = $this->conn->prepare($query);
    
        // sanitize
        $this->article_title=htmlspecialchars(strip_tags($this->article_title));
        $this->article_text=htmlspecialchars(strip_tags($this->article_text));
        $this->article_images=htmlspecialchars(strip_tags($this->article_images));
        $this->user_id=htmlspecialchars(strip_tags($this->user_id));
        $this->article_id=htmlspecialchars(strip_tags($this->article_id));
        $this->article_date_created=htmlspecialchars(strip_tags($this->article_date_created));
    
        // bind new values
        $stmt->bindParam(':article_title', $this->article_title);
        $stmt->bindParam(':article_text', $this->article_text);
        $stmt->bindParam(':article_images', $this->article_images);
        $stmt->bindParam(':user_id', $this->user_id);
        $stmt->bindParam(':article_id', $this->article_id);
        $stmt->bindParam(':article_date_created', $this->article_date_created);
    
        // execute the query
        if($stmt->execute()){
            return true;
        }
    
        return false;
    }

    // delete the article
    function delete(){
 
        // delete query
        $query = "DELETE FROM " . $this->table_name . " WHERE article_id = ?";
    
        // prepare query
        $stmt = $this->conn->prepare($query);
    
        // sanitize
        $this->article_id=htmlspecialchars(strip_tags($this->article_id));
    
        // bind id of record to delete
        $stmt->bindParam(1, $this->article_id);
    
        // execute query
        if($stmt->execute()){
            return true;
        }
    
        return false;
     
    }

    // read articles with pagination
    public function readPaging($from_record_num, $records_per_page){
    
        // select query
        $query = "SELECT
                    u.user_name as user_name, a.article_id, a.article_title, 
                    a.article_text, a.article_images, a.user_id, a.article_date_created
                FROM
                    " . $this->table_name . " a
                    LEFT JOIN
                        users u
                            ON a.user_id = u.user_id
                ORDER BY a.article_date_created DESC
                LIMIT ?, ?";
    
        // prepare query statement
        $stmt = $this->conn->prepare( $query );
    
        // bind variable values
        $stmt->bindParam(1, $from_record_num, PDO::PARAM_INT);
        $stmt->bindParam(2, $records_per_page, PDO::PARAM_INT);
    
        // execute query
        $stmt->execute();
    
        // return values from database
        return $stmt;
    }

    // used for paging articles
    public function count(){
        $query = "SELECT COUNT(*) as total_rows FROM " . $this->table_name . "";
    
        $stmt = $this->conn->prepare( $query );
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
        return $row['total_rows'];
    }
}