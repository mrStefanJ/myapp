-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Apr 18, 2019 at 02:08 AM
-- Server version: 5.7.25
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
CREATE TABLE `articles` (
  `article_id` int(11) NOT NULL,
  `article_title` varchar(300) NOT NULL,
  `article_text` varchar(2000) NOT NULL,
  `article_images` varchar(300) NOT NULL,
  `user_id` int(11) NOT NULL,
  `article_date_created` datetime NOT NULL DEFAULT '2019-04-14 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`article_id`, `article_title`, `article_text`, `article_images`, `user_id`, `article_date_created`) VALUES
(1, 'From Redux to Hooks: A Case Study', 'Why it worked for us\r\n\r\nBefore we go into details about \"how\" let\'s focus on the question \"why\". We decided to take this route because our project had very specific requirements.\r\n\r\nMiddle-sized project\r\nTight deadline\r\nSmall global state with infrequent updates\r\nTypeScript everywhere\r\nNo server-side rendering\r\nMark Erikson, one of the maintainers of Redux, recently did a great talk called \"The State of Redux\" in which he addressed some of the myths and misconceptions about Redux. \r\n', 'http://atgbcentral.com/data/out/55/4389056-dog-picture.jpg', 1, '2019-04-14 00:00:00'),
(2, 'Write your first React Hook!', 'Introduction\r\n\r\nOne of the most loved features in React, which helps us a lot while building our application, is the way we can use and manage state.\r\n\r\nIn October 2018, at the React Conf, the React team released a proposal for React 16.8. They introduced React Hooks - a new way to use and manage state throughout our application and perform side-effects in React functional components.\r\n\r\nThis was a huge surprise and nobody expected that proposal, which was enough to get community super excited. A lot of people have been waiting for this for such a long time and are already using it in production, even though it\'s been in alpha version which is not recommended by the React team. The feature has just been released today along with the latest version of React (v16.8), which is one the most awaited releases for sure.', 'https://d17fnq9dkz9hgj.cloudfront.net/uploads/2012/11/153588021-dog-anal-gland-care-632x475.jpg', 2, '2019-04-14 00:00:00'),
(4, 'Write your first React Hook!', 'State in React\r\n\r\nWhen we are just getting started with React, one of the basic concepts that we need to learn is components, how they work, and how to make the best use of them. A component is basically a JavaScript class or a function that optionally accepts properties (props) and returns a React element. With that, we can divide behavior into roles, much like we would with JavaScript functions.\r\n\r\nHowever, we have limitations with components, especially with managing state. We can manage it in React class components, not functional components.', 'https://assets3.thrillist.com/v1/image/2799859/size/tl-horizontal_main_2x.jpg', 1, '2019-03-17 20:35:25'),
(6, 'Stateful Components in React\r\n', 'This type of component is responsible for the management and handling of state throughout our application. We can use Redux, MobX or even the setState to manage state. We can also use lifecycle methods as componentDidMount, componentDidUpdate, etc. But the main question here is: \"Are you going to need to manage and handle data?\"\" If the answer is \"Yes\", you need to write a class component.', 'https://assets3.thrillist.com/v1/image/2799859/size/tl-horizontal_main_2x.jpg', 2, '2019-04-17 19:01:43'),
(7, 'Stateless Components', 'This type of component is basically a function, and it receives data via props. It can\'t manage or handle state -- that\'s why it is called a Stateless Component. In this type of component, we can\'t manage state nor use lifecycle methods. This type of component is also known as a Presentational Component, because it only gives us the power to present the data, not modify it.\r\n\r\nSo, when you need a component just to show data, you\'re going to write a functional component. You can also write a class component just to show data but there\'s no need to do it and a functional component would be a better choice and will make your code more readable.', 'https://www.petmd.com/sites/default/files/kneecap-dislocation-dogs.jpg', 1, '2019-04-17 22:48:56'),
(13, 'setState', 'When we\'re thinking about components in React, we think they can have state. And when we\'re dealing with state in our application, the first option that we have is the setState function, which accepts an object that will be merged in the current state of our component.\r\n\r\nEvery time we call setState, it causes reconciliation. This is the way React updates the DOM. setState function is also asynchronous.\r\n', 'https://www.mathabah.org/wp-content/uploads/2018/03/dog-800x400.jpg', 2, '2019-04-17 19:18:47'),
(14, 'React Hooks finally get released!\r\n', 'React Hooks are the new way to manage and handle state in React. We don\'t get only one hook -- we can get as many hooks as we want to.\r\n\r\nTo start using React Hooks, you need to update your React version to the latest version, the one that supportsHooks, which is 16.8.0 at the time of writing this article.\r\n\r\nWe\'re going to build a simple to-do app, and you\'re going to understand how hooks work pretty well! Now, to start using React Hooks, We need to import the useState hook. This is one of the most important hooks as with this specific hook we\'re going to be able to use state in our functional component.\r\n\r\n    import React, { useState } from \"react\";\r\nThe useState hook takes the initial state as an argument, and it returns an array with 2 elements: the current state, and the updater function.', 'https://www.mathabah.org/wp-content/uploads/2018/03/dog-800x400.jpg', 2, '2019-04-17 19:19:59'),
(15, 'Conclusion', 'React Hooks really came out to change the way we deal and handle state in React. So, technically there\'s no need to write class components just to handle state when we can get the same result with a functional component.\r\n\r\nWriting class components just to handle state is really painful because we have a lot of problems with it, such as:\r\n\r\nWe need to know how to use bind and this correctly.\r\nThey are really hard to test\r\nWe can get a complex code which is hard to maintain.\r\nAs the React docs say:\r\n\r\nHooks embrace functions, but without sacrificing the practical spirit of React.\r\n', 'https://assets3.thrillist.com/v1/image/2799859/size/tl-horizontal_main_2x.jpg', 1, '2019-04-17 22:55:23'),
(17, 'Additional Title ver 3', 'now we are going to place a really looooooong text :D\nadd some more text', 'https://assets3.thrillist.com/v1/image/2799859/size/tl-horizontal_main_2x.jpg', 1, '2019-04-18 00:33:15'),
(18, 'Functional Programming Fundamentals', 'In the past few years, React and Redux have generated a surge of Functional Programming which we often take for granted. However many of us never got a chance to learn the fundamentals.\r\n\r\nIn this post, we’ll cover the fundamentals of Functional Programming and how they apply to modern JavaScript. We’ll also avoid unnecessary jargon like monads and functors and stick to concepts that will make our code better.\r\n\r\nIf you\'d like to learn all the unnecessary jargon, check out my other posts, What The Functor and Mary Had a Little Lambda. I also have an article on map, filter, and reduce.', 'http://atgbcentral.com/data/out/55/4389056-dog-picture.jpg', 1, '2019-04-18 00:40:59'),
(19, 'When is Functional Programming most useful?', 'Before we cover what functional programming is. I think it\'s helpful to define when we use it.\r\n\r\nFunctional Programming is most useful when we’re doing 1 to 1 data transformations.\r\n\r\nIn the code snipped above we have some types listed for a data store, a component, and a functional layer in between them.\r\n\r\nThis functional layer, convertUserMapToArray, converts the data from a format that makes sense to the store to a format that makes sense for the UI. This is what we\'re going to zero in on today.', 'https://www.petmd.com/sites/default/files/kneecap-dislocation-dogs.jpg', 1, '2019-04-18 00:41:50'),
(20, 'Side Effects', 'The no side-effects bit is particularly important, because this is what allows us to trust that a function will always behave the same in any environment. This will help with future concepts.\r\n\r\nNow side-effects aren\'t inherently bad, but you should isolate them to parts of your codebase where you can easily identify them.\r\n\r\nLet\'s take a look a some examples of side effects.', 'https://www.mathabah.org/wp-content/uploads/2018/03/dog-800x400.jpg', 1, '2019-04-18 00:43:14'),
(21, 'Declarative and Imperative\r\n', 'Declarative code describes what it does.\r\nImperative code describes how it does it.\r\nLooking at the two code samples above, we can see a stark contrast. The top block is written using React and just says \"we want a counter on the page.\" This code trusts React, the declarative library, to get it right.\r\n\r\nThe bottom block is using vanilla JS. It explicitly finds a DOM node and updates it. While this is fine for such a simple example this won\'t scale well. What happens when we want multiple counters in multiple locations? React is ready for that, with vanilla JS we have a lot of work to do.\r\n\r\n\r\n \r\nNow it\'s worth noting that declarative code will always end up either compiling down to or being processed by something imperative. What do I mean by that? Well something has to do the DOM mutation. In this case that\'s React. Even with functional languages like Lisp or Haskell they eventually get compiled to imperative machine code.', 'https://www.mathabah.org/wp-content/uploads/2018/03/dog-800x400.jpg', 1, '2019-04-18 00:49:03'),
(22, 'Functional Concepts', 'It\'s now time to move onto functional concepts. Let\'s take these in pairs, the first two separation and composition.\r\n\r\nSeparation\r\n\r\nIf you try to perform effects and logic at the same time, you may create hidden side effects which cause bugs in the logic. Keep functions small. Do one thing at a time, and do it well.\r\nComposition\r\n\r\nPlan for composition. Write functions whose outputs will naturally work as inputs to many other functions. Keep function signatures as simple as possible.', 'https://assets3.thrillist.com/v1/image/2799859/size/tl-horizontal_main_2x.jpg', 1, '2019-04-18 01:11:31');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(300) NOT NULL,
  `password` varchar(30) NOT NULL,
  `user_name` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `user_name`) VALUES
(1, 'admin', 'admin', 'John Doe'),
(2, 'username', 'password', 'Jane Doe');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`article_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `article_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `articles`
--
ALTER TABLE `articles`
  ADD CONSTRAINT `articles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
