<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 
// include database and object files
include_once '../config/database.php';
include_once '../objects/article.php';
 
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// prepare article object
$article = new Article($db);
 
// get id of article to be edited
$data = json_decode(file_get_contents("php://input"), true);
 
// set ID property of article to be edited
$article->article_id = $data['article_id'];
 
// set article property values
$article->article_title = $data['article_title'];
$article->article_text = $data['article_text'];
$article->article_images = $data['article_images'];
$article->user_id = $data['user_id'];
$article->article_date_created = date('Y-m-d H:i:s');
 
// update the article
if($article->update()){
 
    // set response code - 200 ok
    http_response_code(200);
 
    // tell the user
    echo json_encode(array("message" => "Article was updated."));
}
 
// if unable to update the article, tell the user
else{
 
    // set response code - 503 service unavailable
    http_response_code(503);
 
    // tell the user
    echo json_encode(array("message" => "Unable to update article."));
}
?>